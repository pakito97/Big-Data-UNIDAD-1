//1)importamos la sesion apache spark 
import org.apache.spark.sql.SparkSession
//2) crear la variable spark y cargamos el archivo Netflix_2011_2016.csv
val spark = SparkSession.builder().getOrCreate()
val df = spark.read.option("header", "true").option("inferSchema","true")csv("C:/Users/aide0/OneDrive/Escritorio/Practica Evaluatoria/Practica-Evaluatoria/Netflix_2011_2016.csv")

//3)Nombres de las columnas
df.columns

//4)Esquema
df.printSchema ()

//5)Primeras 5 columnas
df.take(5)

// 6)Use describe () to learn about the DataFrame.
df.describe().show

/*7)Crea un nuevo dataframe con una columna nueva llamada “HV Ratio” que es la relación entre el precio de la columna “High” frente a la columna “Volume” de
acciones negociadas por un día. (Hint: Es una operación*/
val df2 = df.withColumn("HV_Ratio", df("High")/df("Volume"))
 df2.show

 //8)¿que dia tuvo el pico mas alto en la columna"close"?
 df.groupBy(dayofmonth(df("date")).alias("Day")).max("High").sort(asc("Day")).show()
 df.groupBy(dayofweek(df("date")).alias("Day")).max("High").sort(asc("Day")).show()

 /*9)Escribe con tus propias palabras en un comentario de tu codigo. ¿Cuál es el significado de la columna Cerrar “Close”?*/

//(Marco)close en la bolsa de valores de netflix del 2011 al 2016, es el valor total de las acciones con las que cerro eese dia.
//(Aide) La columna close se refiere a la comparacion de cual fue el valor con el que cerraros las acciones de Netflix.

//10)¿Cuál es el máximo y mínimo de la columna “Volume”?
df.select(max("Volume"),min("Volume")).show()

/*11)Con Sintaxis Scala/Spark $ conteste los siguiente:
◦ Hint: Basicamente muy parecido a la session de dates, tendran que crear otro
dataframe para contestar algunos de los incisos.*/

val df3 = df.withColumn("Resultados ejer_11", df("High")/df("Volume")/df("Close"))
 df3.show

 //11a)a. ¿Cuántos días fue la columna “Close” inferior a $ 600?
val  preciomenor = df3.filter($"Close" < 600).count

//11b. ¿Que porcentaje del tiempo fue la columna “High” mayor que $ 500?

val tiempo = df3.filter($"High" > 500).count()
val tiempo1 = tiempo * .100

//11c. ¿Cuál es la correlación de Pearson entre columna “High” y la columna “Volumen”?
df3.select(corr("High", "Volume").alias("correlacion")).show()

//11d. ¿Cuál es el máximo de la columna “High” por año?
df3.groupBy(year(df("Date")).alias("Year")).max("High").sort(asc("Year")).show()

//11e. ¿Cuál es el promedio de columna “Close” para cada mes del calendario?
df3.groupBy(month(df("Date")).alias("Month")).avg("Close").sort(asc("Month")).show()